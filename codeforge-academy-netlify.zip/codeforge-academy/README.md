# CodeForge Academy — Netlify

A static, mobile-friendly coding academy prototype. It is designed as a **paid product**, not a donation project.

## Deploy
1. Open Netlify.
2. Choose **Add new project / Deploy manually**.
3. Drag the `codeforge-academy` folder (or ZIP) into the deploy area.
4. No build command is needed.

## Important payment note
The Store UI is ready as a product-selling structure, but the buttons currently show a placeholder. Before accepting real money, connect a payment provider that supports your business, country, age/business requirements, and payout method. Do not collect real payments through the placeholder.

## Included
- Dashboard
- 11 learning paths
- 18 languages
- Starter lesson engine
- Practice areas
- Projects
- Python exam
- XP/progress saved in browser
- Achievements
- Paid Store with SAR pricing
- Dark-first mobile design

This is a strong foundation for expanding toward a FreeCodeCamp-sized curriculum.
